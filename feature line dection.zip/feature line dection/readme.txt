Name of the program:
Fortran code for detecting three types of feature lines in potential-field maps



Title of the manuscript:
An Algorithm for Detecting Three Types of Feature Lines in Potential Fields



Author details:

Name: He, Haoyuan (�κ�Դ) 
E-mail address: hehy18@mails.jlu.edu.cn

Name: Li, Tonglin (��ͩ��) 
E-mail address: litl@jlu.edu.cn

Name: Zhang, Rongzhe (���F��) 
E-mail address: zhangrongzhe_jlu@163.com

Affiliation addresses: College of Geo-exploration Science and Technology, Jilin University, No. 938, Ximinzhu Street, Chaoyang District, Changchun, Jilin, CN.
  
Full postal address: Room 401, Geological Palace, Chao yang Campus, Jilin University, No. 938, Ximinzhu Street, Chaoyang District, Changchun City, Jilin Province, China
